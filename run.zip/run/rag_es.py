import os
from elasticsearch import Elasticsearch
from elasticsearch.helpers import scan
from openai import OpenAI

# 初始化ES客户端


es = Elasticsearch("https://223.72.199.234:9200")

INDEX_NAME = "test_data"  # 替换为你的索引名



def hybrid_search(task_label, query_text, query_embedding, top_k=10):
    """
    混合检索：先按task_label筛选，然后进行向量+标题+内容检索
    :param task_label: 任务标签，用于先筛选相关文档
    :param query_text: 查询文本（用于标题和内容检索）
    :param query_embedding: 查询向量（list或np.array，长度1024）
    :param top_k: 返回结果数
    :return: 检索结果列表
    """
    search_body = {
        "size": top_k,
        "query": {
            "bool": {
                "must": [],  # 必须满足的条件
                "should": [
                    {
                        "match": {
                            "title": {
                                "query": query_text,
                                "boost": 2
                            }
                        }
                    },
                    {
                        "match": {
                            "content": {
                                "query": query_text,
                                "boost": 1
                            }
                        }
                    }
                ],
                "minimum_should_match": 1
            }
        }
    }
    
    # 添加task_label筛选条件
    if task_label:
        search_body["query"]["bool"]["must"].append({
            "match": {
                "taskLabel": task_label
            }
        })

    # 向量检索部分（使用余弦相似度）
    if query_embedding is not None:
        search_body["query"]["bool"]["should"].append({
            "script_score": {
                "query": {"match_all": {}},
                "script": {
                    "source": "cosineSimilarity(params.query_vector, 'content_embedding') + 1.0",
                    "params": {"query_vector": query_embedding}
                }
            }
        })

    res = es.search(index=INDEX_NAME, body=search_body)
    return [hit["_source"] for hit in res["hits"]["hits"]]

def get_embeddings(text):
    """
    生成数据的嵌入向量
    :param data: 输入数据（list或np.array）
    :return: 嵌入向量（list或np.array）
    """
    client = OpenAI(
    base_url="https://dashscope.aliyuncs.com/compatible-mode/v1",
    api_key="sk-71640472b1bd4187ac9fdfcc1448c2f9"
)
    try:
        # 检查文本长度，如果超过8192个字符则截断
        if len(text) > 8192:
            text = text[:8192]
            print(f"文本长度超过8192，已截断到8192个字符")
        
        response = client.embeddings.create(
            model="text-embedding-v4",
            input=text,
            dimensions=1024  # 默认维度
        )
        return response.data[0].embedding
    except Exception as e:
        print(f"Error getting embedding: {e}")
        return None

# 示例用法
if __name__ == "__main__":
    task_label = "知识问答"  # 指定任务标签
    query_text = "人工智能治理隐私保护"
    query_embedding = get_embeddings(query_text)  # 替换为你的查询向量
    results = hybrid_search(task_label, query_text, query_embedding, top_k=10)
    for doc in results:
        print(doc["Title"], doc["Content"][:400])  # 打印标题和内容的前400个字符
        print("**********************"*5)