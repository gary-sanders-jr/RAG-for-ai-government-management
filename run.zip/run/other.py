from openai import OpenAI



def get_answer(question,model="deepseek-chat",client= OpenAI(api_key="sk-9965b6e2a17547a6affd769eb64306cd", base_url="https://api.deepseek.com")):
    # 回答用户提出的案例查询与分析。
    prompt = f"""
            <用户输入提问>
            {question}
            <任务描述>
            你是一个人工智能治理咨询智能助手，你的任务是回答用户输入问题。
"""
    response = client.chat.completions.create(
        model=model,
        messages=[
            {"role": "user", "content": prompt}
        ],
        max_tokens=8192,
        temperature=0.7
    )
    answer = response.choices[0].message.content

    return answer

if __name__ == "__main__":
    question = "如何才能学会大语言模型？"
    result = get_answer(question)
    print(result)  